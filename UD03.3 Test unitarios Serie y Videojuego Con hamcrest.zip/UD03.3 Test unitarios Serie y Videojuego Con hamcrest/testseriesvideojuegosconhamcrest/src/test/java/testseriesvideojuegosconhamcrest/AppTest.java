package testseriesvideojuegosconhamcrest;

import static org.hamcrest.Matchers.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.hamcrest.MatcherAssert.assertThat;

public class AppTest {
    // TEST SERIES
    Serie uno = new Serie("S", 6, "F", "R");
    Serie dos = new Serie("P", 3, "A", "S");

    @Test
    @DisplayName(value = "¿Se rellenaron correctamente los datos de la serie 1?")
    public void datosCorrectosSerie1() {
        assertThat("La serie 1 no tiene datos", uno, is(not(nullValue())));
    }

    @Test
    @DisplayName(value = "¿Se rellenaron correctamente los datos de la serie 2?")
    public void datosCorrectosSerie2() {
        assertThat("La serie dos no tiene datos", dos, is(not(nullValue())));
    }

    @Test
    @DisplayName(value = "¿Las dos series son distintas?")
    public void seriesDistintas() {
        assertThat("Las series son iguales", uno, is(not(equalTo(dos))));
    }

    @Test
    @DisplayName(value = "¿Las dos series son iguales?")
    public void seriesIguales() {
        Serie tres = new Serie("S", "F");
        Serie cuatro = new Serie("S", "F");
        assertThat("La serie no son iguales", tres.equals(cuatro), is(true));
    }

    @Test
    @DisplayName(value = "¿La serie 1 tiene mas temporadas?")
    public void mastemporadas() {
        assertThat("La serie 2 tiene mas temporadas", uno.getnumeroTemporadas(),
                is(greaterThan(dos.getnumeroTemporadas())));
    }

    @Test
    @DisplayName(value = "¿La serie 2 tiene menos temporadas?")
    public void menostemporadas() {
        assertThat("La serie 2 tiene mas temporadas", dos.getnumeroTemporadas(),
                is(lessThan(uno.getnumeroTemporadas())));
    }

    @Test
    @DisplayName(value = "¿La serie 5 tiene mas o las mismas temporadas que la 6?")
    public void temporadasMasOIguales() {
        Serie cinco = new Serie();
        Serie seis = new Serie();
        assertThat("La serie 5 tiene menos que la 6", seis.getnumeroTemporadas(),
                is(greaterThanOrEqualTo(cinco.getnumeroTemporadas())));
    }

    @Test
    @DisplayName(value = "¿La serie 1 esta entregada?")
    public void serieUnoNoEntregada() {
        assertThat("La serie uno esta entregada", uno.isEntregado(), is(false));
    }

    @DisplayName(value = "¿La serie 1 se entrego correctamente?")
    public void serieUnoEntregada() {
        uno.entregar();
        assertThat("La serie uno sigue sin estar entregada", uno.isEntregado(), is(false));
    }

    @Test
    @DisplayName(value = "¿La serie 2 esta entregada?")
    public void serieDosEntregada() {
        dos.entregar();
        assertThat("La serie 2 no esta entregada", dos.isEntregado(), is(true));
    }

    @Test
    @DisplayName(value = "¿La serie 2 fue devuelta correctamente?")
    public void serieDosDevolucion() {
        dos.devolver();
        assertThat("La serie dos sigue devuelta", dos.isEntregado(), is(false));
    }

    @Test
    @DisplayName(value = "¿La serie 1 fue devuelta correctamente, pero sigue entregada?")
    public void serieUnoDevolucion() {
        dos.devolver();
        assertThat("La serie 1 sigue devuelta", dos.isEntregado(), is(false));
    }

    // ----------------------------------------------TEST
    // VIDEOJUEGOS------------------------------------------------------------------
    Videojuego vPrimero = new Videojuego("S", 6, "F", "R");
    Videojuego vSegundo = new Videojuego("P", 9, "A", "S");

    @Test
    @DisplayName(value = "¿Se rellenaron correctamente los datos del videojuego 1?")
    public void datosCorrectosVideojuego1() {
        assertThat("El videojuego 1 no tiene datos", vPrimero, is(not(nullValue())));
    }

    @Test
    @DisplayName(value = "¿Se rellenaron correctamente los datos del videojuego 2?")
    public void datosCorrectosSegundo() {
        assertThat("El videojuego 2 no tiene datos", vSegundo, is(not(nullValue())));
    }

    @Test
    @DisplayName(value = "¿Los dos videojuegos son distintos?")
    public void videojuegosDistintos() {
        assertThat("Los videojuegos son iguales", vPrimero, is(not(equalTo(vSegundo))));
    }

    @Test
    @DisplayName(value = "¿Los dos videojuegos son iguales?")
    public void videojuegosIguales() {
        Videojuego vTercero = new Videojuego("S", "F");
        Videojuego vCuarto = new Videojuego("S", "F");
        assertThat("Los videojuegos son distintos", vTercero.equals(vCuarto), is(true));
    }

    @Test
    @DisplayName(value = "¿El videojuego 2 tiene mas horas de duracion que el uno?")
    public void masHorasDeDuracion() {
        assertThat("El videojuego 1 tiene mas horas de duracion", vSegundo.getHorasEstimadas(),
                is(greaterThan(vPrimero.getHorasEstimadas())));
    }

    @Test
    @DisplayName(value = "¿El videjuego 1 tiene menos horas de duracion que el dos?")
    public void menoshorasDeDuracion() {
        assertThat("El videojuego 2 tiene menos horas de duracion", vPrimero.getHorasEstimadas(),
                is(lessThan(vSegundo.getHorasEstimadas())));
    }

    @Test
    @DisplayName(value = "¿El videojuego 5 tiene menos o las mismas horas de duracion que el 6")
    public void HorasDuracionMasOLasMismas() {
        Videojuego vCinco = new Videojuego();
        Videojuego vSeis = new Videojuego();
        assertThat("El videojuego 5 tiene menos que el 6", vCinco.getHorasEstimadas(),
                is(greaterThanOrEqualTo(vSeis.getHorasEstimadas())));
    }

    @DisplayName(value = "¿El videojuego 7 tiene menos o las mismas horas de duracion que el 6")
    public void HorasDuracionMenosOLasMismas() {
        Videojuego vSeis = new Videojuego();
        Videojuego vSiete = new Videojuego("A", 20, "D", "D");
        assertThat("El videojuego 6 tiene menos que el 7", vSiete.getHorasEstimadas(),
                is(lessThanOrEqualTo(vSeis.getHorasEstimadas())));
    }

    @Test
    @DisplayName(value = "¿El videojuego 1 esta entregado?")
    public void videojuego1NoEntregado() {
        assertThat("El videojuego 1 esta entregado", vPrimero.isEntregado(), is(false));
    }

    @Test
    @DisplayName(value = "¿El videojuego 2 esta entregado?")
    public void videojuego2Entregado() {
        vSegundo.entregar();
        assertThat("El videojuego 2 sigue sin estar entregado", vSegundo.isEntregado(), is(true));
    }

    @Test
    @DisplayName(value = "¿El videojuego 2 fue devuelto correctamente?")
    public void videojuegoDosDevolucion() {
        vSegundo.devolver();
        assertThat("El videojuego 2 sigue entregado", vSegundo.isEntregado(), is(false));
    }
}