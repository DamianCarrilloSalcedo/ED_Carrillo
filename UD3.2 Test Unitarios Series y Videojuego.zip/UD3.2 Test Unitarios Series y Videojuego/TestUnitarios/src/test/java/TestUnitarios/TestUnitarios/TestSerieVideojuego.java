package TestUnitarios.TestUnitarios;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit test for simple App.
 */
public class TestSerieVideojuego {
	
    Serie primeraSerie=new Serie("A", 2, "G", "A");
    Serie segundaSerie=new Serie("A",4,"G","A");
    Videojuego primerVideojuego=new Videojuego("A", 150, "G", "A");
    Videojuego segundoVideojuego=new Videojuego("A", 200, "G", "A");
    //TEST SERIES
    @Test
    @DisplayName ("¿Se han introducido correctamente los datos?")
    public void SerieConDatos() {
    	assertNotNull(primeraSerie, "Los datos de la serie no estan completos");
    }
    @Test
    @DisplayName ("¿Se han introducido correctamente los datos?")
    public void SegundaSerieConDatos() {
    	assertNotNull(segundaSerie, "Los datos de la serie no estan completos");
    }
    @Test
	@DisplayName ("¿Esta entregada actualmente la serie 1?")
    public void NoEntregadaSerie1()
    {
     assertFalse(primeraSerie.isEntregado(), "Esta entregada la serie 1");
    }
    @Test
  	@DisplayName ("¿Esta entregada actualmente la serie 2?")
      public void NoEntregadaSerie2()
      {
       assertFalse(segundaSerie.isEntregado(), "Esta entregada la serie 2");
      }
	@Test
	@DisplayName ("¿Se entrego finalmente la serie 1?")
	public void Serie1ListoYEntregado() {
		primeraSerie.entregar();
		assertTrue(primeraSerie.isEntregado(), "Todavia no se ha entregado la serie 1");
	}
	@Test 
	@DisplayName ("Se ha devuelto la serie 1 pero, ¿sigue entregada?")
	public void DevolucionSerie1() {
		primeraSerie.devolver();
		assertFalse(primeraSerie.isEntregado(),"No se devolvio correctamente la serie 1");
	}
	@Test
	@DisplayName ("¿Las dos series tiene el mismo titulo y creador ")
	public void SeriesIguales() {
		assertTrue(primeraSerie.equals(segundaSerie), "No son iguales");
	}
	@Test
	@DisplayName ("¿Que serie tiene mas temporadas?")
	public void SerieConMasTemporadas() {
		assertEquals(Serie.MAYOR, segundaSerie.compareTo(primeraSerie), "La serie 1 tiene mas temporadas");
	}
	@Test
	@DisplayName ("¿Cual de estas dos series tienen menos temporadas")
	public void SerieConMenosTemporadas() {
	    Serie terceraSerie=new Serie();
	    Serie cuartaSerie=new Serie("D",2,"G","A");
		assertEquals(Serie.MENOR, cuartaSerie.compareTo(terceraSerie), "La serie 4 tiene mas temporadas");
	}
	@Test
	@DisplayName ("¿Estas series tienen las mismas temporadas?")
	public void SeriesContemporadasIguales() {
		Serie quintaSerie=new Serie();
		Serie sextaSerie=new Serie();
		assertEquals(Serie.IGUAL, quintaSerie.compareTo(sextaSerie), "La serie 5 o 6  tienen mas temporadas");
	}
	//TEST VIDEOJUEGOS
	@Test
    @DisplayName ("¿Se han introducido correctamente los datos?")
    public void VideojuegoConDatos() {
    	assertNotNull(primerVideojuego, "Los datos del videojuego 1 no estan completos");
    }
    @Test
    @DisplayName ("¿Se han introducido correctamente los datos?")
    public void SegundoVideoJuegoConDatos() {
    	assertNotNull(segundoVideojuego, "Los datos del videojuego 2 no estan completos");
    }
    @Test
	@DisplayName ("¿Esta entregado actualmente el videojuego 2?")
    public void NoEntregadoVideoJuego2()
    {
     assertFalse(segundoVideojuego.isEntregado(), "Esta entregado el videojuego 2");
    }
    @Test
  	@DisplayName ("¿Esta entregado actualmente el videojuego 1?")
      public void NoEntregadoVideoJuego1()
      {
       assertFalse(primerVideojuego.isEntregado(), "Esta entregado el videojuego 1");
      }
	@Test
	@DisplayName ("¿Se entrego finalmente el videojuego 2?")
	public void VideoJuego2ListoYEntregado() {
		segundoVideojuego.entregar();
		assertTrue(segundoVideojuego.isEntregado(), "Todavia no se ha entregado el videojuego 2");
	}
	@Test 
	@DisplayName ("Se ha devuelto el videojuego 2 pero, ¿sigue entregado?")
	public void DevolucionVideoJuego2() {
		segundoVideojuego.devolver();
		assertFalse(segundoVideojuego.isEntregado(),"No se devolvio correctamente el videojuego 2");
	}
	@Test
	@DisplayName ("¿Los dos videojuegos son iguales?")
	public void VideoJuegosIguales() {
		assertTrue(segundoVideojuego.equals(primerVideojuego), "No son iguales");
	}
	@Test
	@DisplayName ("¿Que videojuego tiene mas horas?")
	public void VideojuegoConMasTemporadas() {
		assertEquals(Videojuego.MAYOR, segundoVideojuego.compareTo(primerVideojuego), "El videojuego 1 tiene mas horas");
	}
	@Test
	@DisplayName ("¿Que videojuego tiene menos horas")
	public void VideojuegoConMenosTemporadas() {
		assertEquals(Videojuego.MENOR, primerVideojuego.compareTo(segundoVideojuego), " El videojuego 2 tiene mas horas");
	}
	@Test
	@DisplayName ("¿Estos videojuegos tienen las mismas horas?")
	public void VideojuegosConHorasIguales() {
		Videojuego tercerVideojuego=new Videojuego();
		Videojuego cuartoVideojuego=new Videojuego();
		assertEquals(Videojuego.IGUAL, tercerVideojuego.compareTo(cuartoVideojuego), "El videojuego 3 o 4  tienen mas horas");
	}
}